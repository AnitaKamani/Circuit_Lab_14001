/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Uni/Madar Lab/LAB/HW11_Kamani_970122680033/RAM64X8/RAM64X8.vhd";



static void work_a_1136348872_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned char t13;
    unsigned int t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 4512);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(51, ng0);
    t1 = (t0 + 4640);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 4704);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(53, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t2 = t1;
    memset(t2, (unsigned char)4, 8U);
    t3 = (t0 + 4768);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t1, 8U);
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)3);
    if (t9 != 0)
        goto LAB2;

LAB4:
LAB3:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t8 = *((unsigned char *)t2);
    t9 = (t8 == (unsigned char)2);
    if (t9 != 0)
        goto LAB38;

LAB40:
LAB39:    t1 = (t0 + 4432);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t10 = (5 - 5);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t3 + t12);
    t4 = (t0 + 8436);
    t13 = 1;
    if (2U == 2U)
        goto LAB8;

LAB9:    t13 = 0;

LAB10:    if (t13 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t10 = (5 - 5);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t2 + t12);
    t3 = (t0 + 8438);
    t8 = 1;
    if (2U == 2U)
        goto LAB16;

LAB17:    t8 = 0;

LAB18:    if (t8 != 0)
        goto LAB14;

LAB15:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t10 = (5 - 5);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t2 + t12);
    t3 = (t0 + 8440);
    t8 = 1;
    if (2U == 2U)
        goto LAB24;

LAB25:    t8 = 0;

LAB26:    if (t8 != 0)
        goto LAB22;

LAB23:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t10 = (5 - 5);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t2 + t12);
    t3 = (t0 + 8442);
    t8 = 1;
    if (2U == 2U)
        goto LAB32;

LAB33:    t8 = 0;

LAB34:    if (t8 != 0)
        goto LAB30;

LAB31:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(56, ng0);
    t15 = (t0 + 4512);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)3;
    xsi_driver_first_trans_fast(t15);
    goto LAB6;

LAB8:    t14 = 0;

LAB11:    if (t14 < 2U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t6 = (t1 + t14);
    t7 = (t4 + t14);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB9;

LAB13:    t14 = (t14 + 1);
    goto LAB11;

LAB14:    xsi_set_current_line(58, ng0);
    t7 = (t0 + 4576);
    t15 = (t7 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB6;

LAB16:    t14 = 0;

LAB19:    if (t14 < 2U)
        goto LAB20;
    else
        goto LAB18;

LAB20:    t5 = (t1 + t14);
    t6 = (t3 + t14);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB17;

LAB21:    t14 = (t14 + 1);
    goto LAB19;

LAB22:    xsi_set_current_line(60, ng0);
    t7 = (t0 + 4640);
    t15 = (t7 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB6;

LAB24:    t14 = 0;

LAB27:    if (t14 < 2U)
        goto LAB28;
    else
        goto LAB26;

LAB28:    t5 = (t1 + t14);
    t6 = (t3 + t14);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB25;

LAB29:    t14 = (t14 + 1);
    goto LAB27;

LAB30:    xsi_set_current_line(62, ng0);
    t7 = (t0 + 4704);
    t15 = (t7 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    *((unsigned char *)t18) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB6;

LAB32:    t14 = 0;

LAB35:    if (t14 < 2U)
        goto LAB36;
    else
        goto LAB34;

LAB36:    t5 = (t1 + t14);
    t6 = (t3 + t14);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB33;

LAB37:    t14 = (t14 + 1);
    goto LAB35;

LAB38:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t10 = (5 - 5);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t3 + t12);
    t4 = (t0 + 8444);
    t13 = 1;
    if (2U == 2U)
        goto LAB44;

LAB45:    t13 = 0;

LAB46:    if (t13 != 0)
        goto LAB41;

LAB43:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t10 = (5 - 5);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t2 + t12);
    t3 = (t0 + 8446);
    t8 = 1;
    if (2U == 2U)
        goto LAB52;

LAB53:    t8 = 0;

LAB54:    if (t8 != 0)
        goto LAB50;

LAB51:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t10 = (5 - 5);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t2 + t12);
    t3 = (t0 + 8448);
    t8 = 1;
    if (2U == 2U)
        goto LAB60;

LAB61:    t8 = 0;

LAB62:    if (t8 != 0)
        goto LAB58;

LAB59:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t10 = (5 - 5);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t2 + t12);
    t3 = (t0 + 8450);
    t8 = 1;
    if (2U == 2U)
        goto LAB68;

LAB69:    t8 = 0;

LAB70:    if (t8 != 0)
        goto LAB66;

LAB67:
LAB42:    goto LAB39;

LAB41:    xsi_set_current_line(67, ng0);
    t15 = (t0 + 2472U);
    t16 = *((char **)t15);
    t15 = (t0 + 4768);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t16, 8U);
    xsi_driver_first_trans_fast_port(t15);
    goto LAB42;

LAB44:    t14 = 0;

LAB47:    if (t14 < 2U)
        goto LAB48;
    else
        goto LAB46;

LAB48:    t6 = (t1 + t14);
    t7 = (t4 + t14);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB45;

LAB49:    t14 = (t14 + 1);
    goto LAB47;

LAB50:    xsi_set_current_line(69, ng0);
    t7 = (t0 + 2632U);
    t15 = *((char **)t7);
    t7 = (t0 + 4768);
    t16 = (t7 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t15, 8U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB42;

LAB52:    t14 = 0;

LAB55:    if (t14 < 2U)
        goto LAB56;
    else
        goto LAB54;

LAB56:    t5 = (t1 + t14);
    t6 = (t3 + t14);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB53;

LAB57:    t14 = (t14 + 1);
    goto LAB55;

LAB58:    xsi_set_current_line(71, ng0);
    t7 = (t0 + 2792U);
    t15 = *((char **)t7);
    t7 = (t0 + 4768);
    t16 = (t7 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t15, 8U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB42;

LAB60:    t14 = 0;

LAB63:    if (t14 < 2U)
        goto LAB64;
    else
        goto LAB62;

LAB64:    t5 = (t1 + t14);
    t6 = (t3 + t14);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB61;

LAB65:    t14 = (t14 + 1);
    goto LAB63;

LAB66:    xsi_set_current_line(73, ng0);
    t7 = (t0 + 2952U);
    t15 = *((char **)t7);
    t7 = (t0 + 4768);
    t16 = (t7 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t15, 8U);
    xsi_driver_first_trans_fast_port(t7);
    goto LAB42;

LAB68:    t14 = 0;

LAB71:    if (t14 < 2U)
        goto LAB72;
    else
        goto LAB70;

LAB72:    t5 = (t1 + t14);
    t6 = (t3 + t14);
    if (*((unsigned char *)t5) != *((unsigned char *)t6))
        goto LAB69;

LAB73:    t14 = (t14 + 1);
    goto LAB71;

}


extern void work_a_1136348872_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1136348872_3212880686_p_0};
	xsi_register_didat("work_a_1136348872_3212880686", "isim/RAM64X8_TB_isim_beh.exe.sim/work/a_1136348872_3212880686.didat");
	xsi_register_executes(pe);
}
