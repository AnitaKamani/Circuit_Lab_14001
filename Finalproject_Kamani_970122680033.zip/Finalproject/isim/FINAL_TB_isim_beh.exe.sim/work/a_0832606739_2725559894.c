/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Uni/Madar Lab/LAB/Finalproject/ALU.vhd";
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );


static void work_a_0832606739_2725559894_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    xsi_set_current_line(29, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 10138);
    t4 = 1;
    if (4U == 4U)
        goto LAB5;

LAB6:    t4 = 0;

LAB7:    if (t4 != 0)
        goto LAB3;

LAB4:
LAB11:    t13 = (t0 + 6776);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = (unsigned char)2;
    xsi_driver_first_trans_fast(t13);

LAB2:    t18 = (t0 + 6520);
    *((int *)t18) = 1;

LAB1:    return;
LAB3:    t8 = (t0 + 6776);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB5:    t5 = 0;

LAB8:    if (t5 < 4U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB6;

LAB10:    t5 = (t5 + 1);
    goto LAB8;

LAB12:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(30, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = (0 - 7);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    t9 = *((unsigned char *)t1);
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t9);
    t11 = (t0 + 6840);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_delta(t11, 7U, 1, 0LL);

LAB2:    t16 = (t0 + 6536);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(31, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = (1 - 7);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    t9 = *((unsigned char *)t1);
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t9);
    t11 = (t0 + 6904);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_delta(t11, 6U, 1, 0LL);

LAB2:    t16 = (t0 + 6552);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(32, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = (2 - 7);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    t9 = *((unsigned char *)t1);
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t9);
    t11 = (t0 + 6968);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_delta(t11, 5U, 1, 0LL);

LAB2:    t16 = (t0 + 6568);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(33, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = (3 - 7);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    t9 = *((unsigned char *)t1);
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t9);
    t11 = (t0 + 7032);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_delta(t11, 4U, 1, 0LL);

LAB2:    t16 = (t0 + 6584);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_5(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(34, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = (4 - 7);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    t9 = *((unsigned char *)t1);
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t9);
    t11 = (t0 + 7096);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_delta(t11, 3U, 1, 0LL);

LAB2:    t16 = (t0 + 6600);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_6(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(35, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = (5 - 7);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    t9 = *((unsigned char *)t1);
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t9);
    t11 = (t0 + 7160);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_delta(t11, 2U, 1, 0LL);

LAB2:    t16 = (t0 + 6616);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_7(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(36, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = (6 - 7);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    t9 = *((unsigned char *)t1);
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t9);
    t11 = (t0 + 7224);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_delta(t11, 1U, 1, 0LL);

LAB2:    t16 = (t0 + 6632);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_8(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(37, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1192U);
    t4 = *((char **)t1);
    t5 = (7 - 7);
    t6 = (t5 * -1);
    t7 = (1U * t6);
    t8 = (0 + t7);
    t1 = (t4 + t8);
    t9 = *((unsigned char *)t1);
    t10 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t9);
    t11 = (t0 + 7288);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_delta(t11, 0U, 1, 0LL);

LAB2:    t16 = (t0 + 6648);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_9(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;

LAB0:    xsi_set_current_line(40, ng0);

LAB3:    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 9972U);
    t4 = (t0 + 1192U);
    t5 = *((char **)t4);
    t4 = (t0 + 9988U);
    t6 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t1, t3, t2, t5, t4);
    t7 = (t1 + 12U);
    t8 = *((unsigned int *)t7);
    t9 = (1U * t8);
    t10 = (8U != t9);
    if (t10 == 1)
        goto LAB5;

LAB6:    t11 = (t0 + 7352);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 8U);
    xsi_driver_first_trans_fast(t11);

LAB2:    t16 = (t0 + 6664);
    *((int *)t16) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t9, 0);
    goto LAB6;

}

static void work_a_0832606739_2725559894_p_10(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    unsigned char t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;

LAB0:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 10142);
    t4 = 1;
    if (4U == 4U)
        goto LAB5;

LAB6:    t4 = 0;

LAB7:    if (t4 != 0)
        goto LAB3;

LAB4:    t18 = (t0 + 1352U);
    t19 = *((char **)t18);
    t18 = (t0 + 10146);
    t21 = 1;
    if (4U == 4U)
        goto LAB13;

LAB14:    t21 = 0;

LAB15:    if (t21 != 0)
        goto LAB11;

LAB12:    t35 = (t0 + 1352U);
    t36 = *((char **)t35);
    t35 = (t0 + 10150);
    t38 = 1;
    if (4U == 4U)
        goto LAB21;

LAB22:    t38 = 0;

LAB23:    if (t38 != 0)
        goto LAB19;

LAB20:
LAB27:    t48 = xsi_get_transient_memory(8U);
    memset(t48, 0, 8U);
    t49 = t48;
    memset(t49, (unsigned char)2, 8U);
    t50 = (t0 + 7416);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    t53 = (t52 + 56U);
    t54 = *((char **)t53);
    memcpy(t54, t48, 8U);
    xsi_driver_first_trans_fast_port(t50);

LAB2:    t55 = (t0 + 6680);
    *((int *)t55) = 1;

LAB1:    return;
LAB3:    t8 = (t0 + 1832U);
    t9 = *((char **)t8);
    t10 = (8 - 7);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t8 = (t9 + t12);
    t13 = (t0 + 7416);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t8, 8U);
    xsi_driver_first_trans_fast_port(t13);
    goto LAB2;

LAB5:    t5 = 0;

LAB8:    if (t5 < 4U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB6;

LAB10:    t5 = (t5 + 1);
    goto LAB8;

LAB11:    t25 = (t0 + 1832U);
    t26 = *((char **)t25);
    t27 = (8 - 7);
    t28 = (t27 * 1U);
    t29 = (0 + t28);
    t25 = (t26 + t29);
    t30 = (t0 + 7416);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    memcpy(t34, t25, 8U);
    xsi_driver_first_trans_fast_port(t30);
    goto LAB2;

LAB13:    t22 = 0;

LAB16:    if (t22 < 4U)
        goto LAB17;
    else
        goto LAB15;

LAB17:    t23 = (t19 + t22);
    t24 = (t18 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB14;

LAB18:    t22 = (t22 + 1);
    goto LAB16;

LAB19:    t42 = (t0 + 1992U);
    t43 = *((char **)t42);
    t42 = (t0 + 7416);
    t44 = (t42 + 56U);
    t45 = *((char **)t44);
    t46 = (t45 + 56U);
    t47 = *((char **)t46);
    memcpy(t47, t43, 8U);
    xsi_driver_first_trans_fast_port(t42);
    goto LAB2;

LAB21:    t39 = 0;

LAB24:    if (t39 < 4U)
        goto LAB25;
    else
        goto LAB23;

LAB25:    t40 = (t36 + t39);
    t41 = (t35 + t39);
    if (*((unsigned char *)t40) != *((unsigned char *)t41))
        goto LAB22;

LAB26:    t39 = (t39 + 1);
    goto LAB24;

LAB28:    goto LAB2;

}

static void work_a_0832606739_2725559894_p_11(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    char *t7;
    unsigned char t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    unsigned char t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned char t33;
    unsigned int t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    unsigned char t40;
    unsigned int t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned char t49;
    char *t50;
    char *t51;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    unsigned char t60;
    unsigned int t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;

LAB0:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1832U);
    t3 = *((char **)t2);
    t4 = (8 - 7);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t2 = (t3 + t6);
    t7 = (t0 + 10154);
    t9 = 1;
    if (8U == 8U)
        goto LAB8;

LAB9:    t9 = 0;

LAB10:    if (t9 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:    t26 = (t0 + 1832U);
    t27 = *((char **)t26);
    t28 = (8 - 7);
    t29 = (t28 * 1U);
    t30 = (0 + t29);
    t26 = (t27 + t30);
    t31 = (t0 + 10166);
    t33 = 1;
    if (8U == 8U)
        goto LAB25;

LAB26:    t33 = 0;

LAB27:    if (t33 == 1)
        goto LAB22;

LAB23:    t25 = (unsigned char)0;

LAB24:    if (t25 != 0)
        goto LAB20;

LAB21:    t50 = (t0 + 1992U);
    t51 = *((char **)t50);
    t50 = (t0 + 10178);
    t53 = 1;
    if (8U == 8U)
        goto LAB42;

LAB43:    t53 = 0;

LAB44:    if (t53 == 1)
        goto LAB39;

LAB40:    t49 = (unsigned char)0;

LAB41:    if (t49 != 0)
        goto LAB37;

LAB38:
LAB54:    t69 = (t0 + 7480);
    t70 = (t69 + 56U);
    t71 = *((char **)t70);
    t72 = (t71 + 56U);
    t73 = *((char **)t72);
    *((unsigned char *)t73) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t69);

LAB2:    t74 = (t0 + 6696);
    *((int *)t74) = 1;

LAB1:    return;
LAB3:    t20 = (t0 + 7480);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    *((unsigned char *)t24) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t20);
    goto LAB2;

LAB5:    t13 = (t0 + 1352U);
    t14 = *((char **)t13);
    t13 = (t0 + 10162);
    t16 = 1;
    if (4U == 4U)
        goto LAB14;

LAB15:    t16 = 0;

LAB16:    t1 = t16;
    goto LAB7;

LAB8:    t10 = 0;

LAB11:    if (t10 < 8U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t11 = (t2 + t10);
    t12 = (t7 + t10);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB9;

LAB13:    t10 = (t10 + 1);
    goto LAB11;

LAB14:    t17 = 0;

LAB17:    if (t17 < 4U)
        goto LAB18;
    else
        goto LAB16;

LAB18:    t18 = (t14 + t17);
    t19 = (t13 + t17);
    if (*((unsigned char *)t18) != *((unsigned char *)t19))
        goto LAB15;

LAB19:    t17 = (t17 + 1);
    goto LAB17;

LAB20:    t44 = (t0 + 7480);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    *((unsigned char *)t48) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t44);
    goto LAB2;

LAB22:    t37 = (t0 + 1352U);
    t38 = *((char **)t37);
    t37 = (t0 + 10174);
    t40 = 1;
    if (4U == 4U)
        goto LAB31;

LAB32:    t40 = 0;

LAB33:    t25 = t40;
    goto LAB24;

LAB25:    t34 = 0;

LAB28:    if (t34 < 8U)
        goto LAB29;
    else
        goto LAB27;

LAB29:    t35 = (t26 + t34);
    t36 = (t31 + t34);
    if (*((unsigned char *)t35) != *((unsigned char *)t36))
        goto LAB26;

LAB30:    t34 = (t34 + 1);
    goto LAB28;

LAB31:    t41 = 0;

LAB34:    if (t41 < 4U)
        goto LAB35;
    else
        goto LAB33;

LAB35:    t42 = (t38 + t41);
    t43 = (t37 + t41);
    if (*((unsigned char *)t42) != *((unsigned char *)t43))
        goto LAB32;

LAB36:    t41 = (t41 + 1);
    goto LAB34;

LAB37:    t64 = (t0 + 7480);
    t65 = (t64 + 56U);
    t66 = *((char **)t65);
    t67 = (t66 + 56U);
    t68 = *((char **)t67);
    *((unsigned char *)t68) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t64);
    goto LAB2;

LAB39:    t57 = (t0 + 1352U);
    t58 = *((char **)t57);
    t57 = (t0 + 10186);
    t60 = 1;
    if (4U == 4U)
        goto LAB48;

LAB49:    t60 = 0;

LAB50:    t49 = t60;
    goto LAB41;

LAB42:    t54 = 0;

LAB45:    if (t54 < 8U)
        goto LAB46;
    else
        goto LAB44;

LAB46:    t55 = (t51 + t54);
    t56 = (t50 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB43;

LAB47:    t54 = (t54 + 1);
    goto LAB45;

LAB48:    t61 = 0;

LAB51:    if (t61 < 4U)
        goto LAB52;
    else
        goto LAB50;

LAB52:    t62 = (t58 + t61);
    t63 = (t57 + t61);
    if (*((unsigned char *)t62) != *((unsigned char *)t63))
        goto LAB49;

LAB53:    t61 = (t61 + 1);
    goto LAB51;

LAB55:    goto LAB2;

}


extern void work_a_0832606739_2725559894_init()
{
	static char *pe[] = {(void *)work_a_0832606739_2725559894_p_0,(void *)work_a_0832606739_2725559894_p_1,(void *)work_a_0832606739_2725559894_p_2,(void *)work_a_0832606739_2725559894_p_3,(void *)work_a_0832606739_2725559894_p_4,(void *)work_a_0832606739_2725559894_p_5,(void *)work_a_0832606739_2725559894_p_6,(void *)work_a_0832606739_2725559894_p_7,(void *)work_a_0832606739_2725559894_p_8,(void *)work_a_0832606739_2725559894_p_9,(void *)work_a_0832606739_2725559894_p_10,(void *)work_a_0832606739_2725559894_p_11};
	xsi_register_didat("work_a_0832606739_2725559894", "isim/FINAL_TB_isim_beh.exe.sim/work/a_0832606739_2725559894.didat");
	xsi_register_executes(pe);
}
