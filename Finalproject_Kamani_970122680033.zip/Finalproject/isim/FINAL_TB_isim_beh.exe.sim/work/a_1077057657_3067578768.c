/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Uni/Madar Lab/LAB/Finalproject/ALU_Controller.vhd";



static void work_a_1077057657_3067578768_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t18;
    unsigned int t19;
    char *t20;
    char *t21;
    char *t22;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned char t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    char *t44;
    char *t45;
    unsigned char t47;
    unsigned int t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned char t54;
    unsigned int t55;
    char *t56;
    char *t57;
    char *t58;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned char t65;
    char *t66;
    char *t67;
    unsigned char t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    unsigned char t76;
    unsigned int t77;
    char *t78;
    char *t79;
    char *t80;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    char *t89;
    char *t90;
    char *t91;
    char *t92;
    char *t93;
    char *t94;

LAB0:    xsi_set_current_line(14, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 4592);
    t4 = 1;
    if (2U == 2U)
        goto LAB5;

LAB6:    t4 = 0;

LAB7:    if (t4 != 0)
        goto LAB3;

LAB4:    t15 = (t0 + 1192U);
    t16 = *((char **)t15);
    t15 = (t0 + 4598);
    t18 = 1;
    if (2U == 2U)
        goto LAB13;

LAB14:    t18 = 0;

LAB15:    if (t18 != 0)
        goto LAB11;

LAB12:    t29 = (t0 + 1192U);
    t30 = *((char **)t29);
    t29 = (t0 + 4604);
    t32 = 1;
    if (2U == 2U)
        goto LAB21;

LAB22:    t32 = 0;

LAB23:    if (t32 != 0)
        goto LAB19;

LAB20:    t44 = (t0 + 1192U);
    t45 = *((char **)t44);
    t44 = (t0 + 4610);
    t47 = 1;
    if (2U == 2U)
        goto LAB32;

LAB33:    t47 = 0;

LAB34:    if (t47 == 1)
        goto LAB29;

LAB30:    t43 = (unsigned char)0;

LAB31:    if (t43 != 0)
        goto LAB27;

LAB28:    t66 = (t0 + 1192U);
    t67 = *((char **)t66);
    t66 = (t0 + 4622);
    t69 = 1;
    if (2U == 2U)
        goto LAB49;

LAB50:    t69 = 0;

LAB51:    if (t69 == 1)
        goto LAB46;

LAB47:    t65 = (unsigned char)0;

LAB48:    if (t65 != 0)
        goto LAB44;

LAB45:
LAB61:    t87 = (t0 + 4634);
    t89 = (t0 + 2912);
    t90 = (t89 + 56U);
    t91 = *((char **)t90);
    t92 = (t91 + 56U);
    t93 = *((char **)t92);
    memcpy(t93, t87, 4U);
    xsi_driver_first_trans_fast_port(t89);

LAB2:    t94 = (t0 + 2832);
    *((int *)t94) = 1;

LAB1:    return;
LAB3:    t8 = (t0 + 4594);
    t10 = (t0 + 2912);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t8, 4U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB2;

LAB5:    t5 = 0;

LAB8:    if (t5 < 2U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB6;

LAB10:    t5 = (t5 + 1);
    goto LAB8;

LAB11:    t22 = (t0 + 4600);
    t24 = (t0 + 2912);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t22, 4U);
    xsi_driver_first_trans_fast_port(t24);
    goto LAB2;

LAB13:    t19 = 0;

LAB16:    if (t19 < 2U)
        goto LAB17;
    else
        goto LAB15;

LAB17:    t20 = (t16 + t19);
    t21 = (t15 + t19);
    if (*((unsigned char *)t20) != *((unsigned char *)t21))
        goto LAB14;

LAB18:    t19 = (t19 + 1);
    goto LAB16;

LAB19:    t36 = (t0 + 4606);
    t38 = (t0 + 2912);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    memcpy(t42, t36, 4U);
    xsi_driver_first_trans_fast_port(t38);
    goto LAB2;

LAB21:    t33 = 0;

LAB24:    if (t33 < 2U)
        goto LAB25;
    else
        goto LAB23;

LAB25:    t34 = (t30 + t33);
    t35 = (t29 + t33);
    if (*((unsigned char *)t34) != *((unsigned char *)t35))
        goto LAB22;

LAB26:    t33 = (t33 + 1);
    goto LAB24;

LAB27:    t58 = (t0 + 4618);
    t60 = (t0 + 2912);
    t61 = (t60 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    memcpy(t64, t58, 4U);
    xsi_driver_first_trans_fast_port(t60);
    goto LAB2;

LAB29:    t51 = (t0 + 1032U);
    t52 = *((char **)t51);
    t51 = (t0 + 4612);
    t54 = 1;
    if (6U == 6U)
        goto LAB38;

LAB39:    t54 = 0;

LAB40:    t43 = t54;
    goto LAB31;

LAB32:    t48 = 0;

LAB35:    if (t48 < 2U)
        goto LAB36;
    else
        goto LAB34;

LAB36:    t49 = (t45 + t48);
    t50 = (t44 + t48);
    if (*((unsigned char *)t49) != *((unsigned char *)t50))
        goto LAB33;

LAB37:    t48 = (t48 + 1);
    goto LAB35;

LAB38:    t55 = 0;

LAB41:    if (t55 < 6U)
        goto LAB42;
    else
        goto LAB40;

LAB42:    t56 = (t52 + t55);
    t57 = (t51 + t55);
    if (*((unsigned char *)t56) != *((unsigned char *)t57))
        goto LAB39;

LAB43:    t55 = (t55 + 1);
    goto LAB41;

LAB44:    t80 = (t0 + 4630);
    t82 = (t0 + 2912);
    t83 = (t82 + 56U);
    t84 = *((char **)t83);
    t85 = (t84 + 56U);
    t86 = *((char **)t85);
    memcpy(t86, t80, 4U);
    xsi_driver_first_trans_fast_port(t82);
    goto LAB2;

LAB46:    t73 = (t0 + 1032U);
    t74 = *((char **)t73);
    t73 = (t0 + 4624);
    t76 = 1;
    if (6U == 6U)
        goto LAB55;

LAB56:    t76 = 0;

LAB57:    t65 = t76;
    goto LAB48;

LAB49:    t70 = 0;

LAB52:    if (t70 < 2U)
        goto LAB53;
    else
        goto LAB51;

LAB53:    t71 = (t67 + t70);
    t72 = (t66 + t70);
    if (*((unsigned char *)t71) != *((unsigned char *)t72))
        goto LAB50;

LAB54:    t70 = (t70 + 1);
    goto LAB52;

LAB55:    t77 = 0;

LAB58:    if (t77 < 6U)
        goto LAB59;
    else
        goto LAB57;

LAB59:    t78 = (t74 + t77);
    t79 = (t73 + t77);
    if (*((unsigned char *)t78) != *((unsigned char *)t79))
        goto LAB56;

LAB60:    t77 = (t77 + 1);
    goto LAB58;

LAB62:    goto LAB2;

}


extern void work_a_1077057657_3067578768_init()
{
	static char *pe[] = {(void *)work_a_1077057657_3067578768_p_0};
	xsi_register_didat("work_a_1077057657_3067578768", "isim/FINAL_TB_isim_beh.exe.sim/work/a_1077057657_3067578768.didat");
	xsi_register_executes(pe);
}
